-- =====================================================================
-- PLATFORM V11.0-RC1 — SAFE ROLLBACK / FALLBACK TO V10.2.10
-- ---------------------------------------------------------------------
-- This is intentionally NON-DESTRUCTIVE:
-- * It disables the V11 feature flag.
-- * It preserves all V11 data for investigation / later recovery.
-- * It does NOT drop or alter any V10 object.
-- After running, open the preserved V10.2.10 HTML baseline.
-- =====================================================================

begin;

update public.platform_features
set enabled=false,
    payload = coalesce(payload,'{}'::jsonb) ||
              jsonb_build_object(
                'mode','rollback',
                'rolled_back_at',now(),
                'fallback','V10.2.10'
              ),
    updated_at=now(),
    updated_by=auth.uid()
where feature_key='project_workspace_v11';

commit;

select jsonb_pretty(
  jsonb_build_object(
    'feature_key','project_workspace_v11',
    'enabled',
      (select enabled from public.platform_features
       where feature_key='project_workspace_v11'),
    'v11_data_preserved',true,
    'v10_objects_dropped',false,
    'fallback_html','platform-v10_2_10_assignment_availability_fix.html'
  )
) as v11_safe_rollback_verification;
