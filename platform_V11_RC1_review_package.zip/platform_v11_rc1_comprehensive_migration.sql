-- =====================================================================
-- PLATFORM V11.0-RC1 — COMPREHENSIVE PROJECT WORKSPACE MIGRATION
-- Additive / backward-compatible with V10.2.10
-- ---------------------------------------------------------------------
-- IMPORTANT:
--   * No existing V10 table is dropped or renamed.
--   * V10.2.10 remains usable as the rollback baseline.
--   * New finance/document tables are additive.
--   * Run in Supabase SQL Editor as postgres / migration owner.
-- =====================================================================

begin;

create extension if not exists pgcrypto;

-- =====================================================================
-- 0. FEATURE FLAG / RELEASE CONTROL
-- =====================================================================

create table if not exists public.platform_features (
  feature_key text primary key,
  enabled boolean not null default false,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by uuid null references public.profiles(id)
);

insert into public.platform_features(feature_key, enabled, payload)
values (
  'project_workspace_v11',
  false,
  jsonb_build_object(
    'release','V11.0-RC1',
    'mode','review',
    'baseline','V10.2.10'
  )
)
on conflict (feature_key) do update
set payload = excluded.payload,
    updated_at = now();

-- =====================================================================
-- 1. SECURITY HELPERS
-- =====================================================================

create or replace function public.can_access_project_v11(p_project_id uuid)
returns boolean
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_role text;
  v_govs integer[];
begin
  if auth.uid() is null then
    return false;
  end if;

  v_role := public.my_role();
  v_govs := coalesce(public.my_governorate_ids(), array[]::integer[]);

  if v_role in ('admin','followup') then
    return true;
  end if;

  if public.is_project_manager(p_project_id) then
    return true;
  end if;

  if v_role in ('region','office','committee') then
    return exists (
      select 1
      from public.project_governorates pg
      where pg.project_id = p_project_id
        and pg.governorate_id = any(v_govs)
    );
  end if;

  return false;
end;
$$;

create or replace function public.can_operate_project_v11(p_project_id uuid)
returns boolean
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_role text;
  v_govs integer[];
begin
  if auth.uid() is null then
    return false;
  end if;

  v_role := public.my_role();
  v_govs := coalesce(public.my_governorate_ids(), array[]::integer[]);

  if v_role = 'admin' or public.is_project_manager(p_project_id) then
    return true;
  end if;

  if v_role in ('region','office') then
    return exists (
      select 1
      from public.project_governorates pg
      where pg.project_id = p_project_id
        and pg.governorate_id = any(v_govs)
    );
  end if;

  return false;
end;
$$;

create or replace function public.can_manage_project_finance_v11(p_project_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select
    auth.uid() is not null
    and (
      public.my_role() = 'admin'
      or public.is_project_manager(p_project_id)
    );
$$;

create or replace function public.can_read_project_finance_v11(p_project_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select
    auth.uid() is not null
    and public.can_access_project_v11(p_project_id)
    and public.my_role() in ('admin','project_manager','region','followup');
$$;

revoke execute on function public.can_access_project_v11(uuid) from public, anon;
revoke execute on function public.can_operate_project_v11(uuid) from public, anon;
revoke execute on function public.can_manage_project_finance_v11(uuid) from public, anon;
revoke execute on function public.can_read_project_finance_v11(uuid) from public, anon;

grant execute on function public.can_access_project_v11(uuid) to authenticated, service_role;
grant execute on function public.can_operate_project_v11(uuid) to authenticated, service_role;
grant execute on function public.can_manage_project_finance_v11(uuid) to authenticated, service_role;
grant execute on function public.can_read_project_finance_v11(uuid) to authenticated, service_role;

-- =====================================================================
-- 2. PROJECT WORKSPACE METADATA
-- =====================================================================

create table if not exists public.project_versions (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  version_no integer not null,
  effective_from date not null,
  reason text not null,
  notes text,
  status text not null default 'active'
    check (status in ('draft','active','superseded','cancelled')),
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  unique(project_id, version_no)
);

create table if not exists public.project_members (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  profile_id uuid not null references public.profiles(id) on delete cascade,
  project_role text not null,
  governorate_id integer references public.governorates(id),
  can_assign boolean not null default false,
  can_review boolean not null default false,
  can_approve boolean not null default false,
  can_view_finance boolean not null default false,
  active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  unique(project_id, profile_id, project_role, governorate_id)
);

create table if not exists public.project_events (
  id bigserial primary key,
  project_id uuid not null references public.projects(id) on delete cascade,
  event_type text not null,
  entity_type text,
  entity_id uuid,
  title text not null,
  details jsonb not null default '{}'::jsonb,
  actor_id uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create index if not exists idx_project_versions_project
  on public.project_versions(project_id, effective_from desc);

create index if not exists idx_project_members_project
  on public.project_members(project_id, active);

create index if not exists idx_project_events_project
  on public.project_events(project_id, created_at desc);

-- =====================================================================
-- 3. FIELD EXECUTION BALANCES
-- No questionnaire/case data is stored here: only aggregate balances.
-- =====================================================================

create table if not exists public.execution_balances (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  assignment_id uuid not null references public.assignments(id) on delete restrict,
  work_unit_id uuid references public.work_units(id) on delete set null,
  balance_date date not null,
  target_count integer not null default 0 check (target_count >= 0),

  full_count integer not null default 0 check (full_count >= 0),
  partial_count integer not null default 0 check (partial_count >= 0),
  excluded_count integer not null default 0 check (excluded_count >= 0),
  in_progress_count integer not null default 0 check (in_progress_count >= 0),
  not_started_count integer not null default 0 check (not_started_count >= 0),

  status text not null default 'draft'
    check (status in ('draft','approved','cancelled')),
  notes text,
  created_by uuid references public.profiles(id),
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint execution_balances_sum_check
  check (
    target_count =
      full_count + partial_count + excluded_count +
      in_progress_count + not_started_count
  ),

  unique(project_id, assignment_id, work_unit_id, balance_date)
);

create index if not exists idx_execution_balances_project_date
  on public.execution_balances(project_id, balance_date desc);

create index if not exists idx_execution_balances_assignment
  on public.execution_balances(assignment_id, balance_date desc);

create table if not exists public.execution_status_factors (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  status_key text not null
    check (status_key in (
      'full','partial','excluded','in_progress','not_started'
    )),
  factor numeric(12,6) not null default 0 check (factor >= 0),
  is_configured boolean not null default false,
  notes text,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now(),
  unique(project_id, status_key)
);

-- Seed status factors for all existing projects.
-- Full completion and unfinished states are deterministic.
-- Partial/excluded are intentionally left unconfigured until the project
-- owner decides their financial treatment.
insert into public.execution_status_factors(project_id,status_key,factor,is_configured,notes)
select p.id, x.status_key, x.factor, x.is_configured, x.notes
from public.projects p
cross join (
  values
    ('full'::text,        1.0::numeric, true,  'استيفاء كامل'),
    ('partial'::text,     0.0::numeric, false, 'يلزم تحديد معامل مالي للمشروع'),
    ('excluded'::text,    0.0::numeric, false, 'يلزم تحديد معامل مالي للمشروع'),
    ('in_progress'::text, 0.0::numeric, true,  'لا يستحق قبل الإتمام'),
    ('not_started'::text, 0.0::numeric, true,  'لا يستحق قبل بدء العمل')
) as x(status_key,factor,is_configured,notes)
on conflict (project_id,status_key) do nothing;

-- =====================================================================
-- 4. QUALITY INCIDENTS / FINANCIAL PENALTIES
-- =====================================================================

create table if not exists public.quality_incidents (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  assignment_id uuid references public.assignments(id) on delete set null,
  individual_id uuid not null references public.individuals(id) on delete restrict,
  work_unit_id uuid references public.work_units(id) on delete set null,
  incident_date date not null default current_date,

  category text not null,
  severity text not null default 'minor'
    check (severity in ('minor','medium','major','critical')),
  description text not null,
  evidence_url text,

  status text not null default 'reported'
    check (status in (
      'reported','under_review','confirmed','rejected','cancelled'
    )),

  financial_effect_type text not null default 'none'
    check (financial_effect_type in ('none','fixed','percentage','per_unit')),
  financial_value numeric(14,2) not null default 0 check (financial_value >= 0),
  financial_base_amount numeric(14,2) not null default 0 check (financial_base_amount >= 0),
  financial_quantity numeric(14,3) not null default 0 check (financial_quantity >= 0),
  calculated_penalty numeric(14,2) not null default 0 check (calculated_penalty >= 0),

  reported_by uuid references public.profiles(id),
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  review_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_quality_incidents_project
  on public.quality_incidents(project_id, incident_date desc);

create index if not exists idx_quality_incidents_individual
  on public.quality_incidents(individual_id, incident_date desc);

-- =====================================================================
-- 5. TRAINING EVENTS + FINANCIAL STRUCTURE
-- =====================================================================

create table if not exists public.training_events (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  event_code text not null,
  title text not null,
  training_type text not null default 'governorate'
    check (training_type in ('central','governorate','regional','other')),
  location text,
  start_date date not null,
  end_date date not null,
  status text not null default 'draft'
    check (status in (
      'draft','active','closed','financial_review','approved','posted','cancelled'
    )),
  notes text,
  created_by uuid references public.profiles(id),
  closed_by uuid references public.profiles(id),
  closed_at timestamptz,
  created_at timestamptz not null default now(),
  constraint training_events_dates_check check (end_date >= start_date),
  unique(project_id, event_code)
);

create table if not exists public.training_financial_rates (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  training_event_id uuid references public.training_events(id) on delete cascade,
  training_role text not null
    check (training_role in ('trainee','trainer','coordinator','supervisor')),
  calc_basis text not null
    check (calc_basis in ('per_day','fixed')),
  amount numeric(14,2) not null check (amount >= 0),
  status text not null default 'active'
    check (status in ('active','inactive')),
  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create index if not exists idx_training_rates_event
  on public.training_financial_rates(training_event_id, training_role, status);

create table if not exists public.training_participants (
  id uuid primary key default gen_random_uuid(),
  training_event_id uuid not null references public.training_events(id) on delete cascade,
  individual_id uuid not null references public.individuals(id) on delete restrict,
  assignment_id uuid references public.assignments(id) on delete set null,

  training_role text not null default 'trainee'
    check (training_role in ('trainee','trainer','coordinator','supervisor')),
  attendance_days numeric(10,2) not null default 0 check (attendance_days >= 0),
  participant_status text not null default 'eligible'
    check (participant_status in ('eligible','ineligible','cancelled')),

  applied_rate numeric(14,2) not null default 0 check (applied_rate >= 0),
  entitlement_amount numeric(14,2) not null default 0 check (entitlement_amount >= 0),

  -- Immutable document snapshot inputs.
  full_name_snapshot text,
  job_title_snapshot text,
  worker_code_snapshot text,
  project_slot_code_snapshot text,
  national_id_snapshot text,
  contract_type_snapshot text,

  notes text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  unique(training_event_id, individual_id, training_role)
);

create index if not exists idx_training_participants_event
  on public.training_participants(training_event_id);

-- Snapshot participant identity / job at the time of enrollment.
create or replace function public.v11_training_participant_snapshot()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_project_id uuid;
  v_assignment_id uuid;
  v_assignment_role text;
  v_assignment_code text;
  v_individual record;
begin
  select te.project_id
  into v_project_id
  from public.training_events te
  where te.id = new.training_event_id;

  select
    i.full_name,
    i.national_id,
    i.contract_type,
    i.internal_employee_code
  into v_individual
  from public.individuals i
  where i.id = new.individual_id;

  if new.assignment_id is not null then
    select a.id, a.role, ss.code
    into v_assignment_id, v_assignment_role, v_assignment_code
    from public.assignments a
    left join public.structure_slots ss on ss.id = a.slot_id
    where a.id = new.assignment_id
      and a.project_id = v_project_id
      and a.individual_id = new.individual_id;
  else
    select a.id, a.role, ss.code
    into v_assignment_id, v_assignment_role, v_assignment_code
    from public.assignments a
    left join public.structure_slots ss on ss.id = a.slot_id
    where a.project_id = v_project_id
      and a.individual_id = new.individual_id
    order by
      case when a.status = 'active' then 0 else 1 end,
      a.start_date desc
    limit 1;

    new.assignment_id := v_assignment_id;
  end if;

  new.full_name_snapshot := v_individual.full_name;
  new.national_id_snapshot := v_individual.national_id;
  new.contract_type_snapshot := v_individual.contract_type;
  new.job_title_snapshot := coalesce(v_assignment_role, new.training_role);
  new.project_slot_code_snapshot := v_assignment_code;
  new.worker_code_snapshot :=
    coalesce(nullif(v_individual.internal_employee_code,''), v_assignment_code);

  return new;
end;
$$;

drop trigger if exists trg_v11_training_participant_snapshot
on public.training_participants;

create trigger trg_v11_training_participant_snapshot
before insert or update of individual_id, assignment_id, training_event_id
on public.training_participants
for each row
execute function public.v11_training_participant_snapshot();

-- =====================================================================
-- 6. REWARDS / TRANSPORT / ADVANCES
-- =====================================================================

create table if not exists public.project_rewards (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  individual_id uuid not null references public.individuals(id) on delete restrict,
  assignment_id uuid references public.assignments(id) on delete set null,
  reward_date date not null default current_date,
  reward_type text not null,
  description text not null,
  calc_type text not null default 'fixed'
    check (calc_type in ('fixed','percentage','per_unit')),
  base_amount numeric(14,2) not null default 0 check (base_amount >= 0),
  percentage numeric(8,4) not null default 0 check (percentage >= 0),
  quantity numeric(14,3) not null default 0 check (quantity >= 0),
  rate numeric(14,2) not null default 0 check (rate >= 0),
  amount numeric(14,2) not null default 0 check (amount >= 0),
  status text not null default 'draft'
    check (status in ('draft','approved','posted','cancelled')),
  created_by uuid references public.profiles(id),
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.transport_entitlements (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  individual_id uuid not null references public.individuals(id) on delete restrict,
  assignment_id uuid references public.assignments(id) on delete set null,
  transport_date date not null default current_date,
  location_description text,
  calc_type text not null default 'fixed'
    check (calc_type in ('fixed','per_day','per_trip')),
  quantity numeric(14,3) not null default 1 check (quantity >= 0),
  rate numeric(14,2) not null default 0 check (rate >= 0),
  amount numeric(14,2) not null default 0 check (amount >= 0),
  status text not null default 'draft'
    check (status in ('draft','approved','posted','cancelled')),
  created_by uuid references public.profiles(id),
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.project_advances (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  individual_id uuid not null references public.individuals(id) on delete restrict,
  assignment_id uuid references public.assignments(id) on delete set null,
  advance_no integer not null,
  advance_date date not null default current_date,
  advance_type text not null
    check (advance_type in (
      'fixed','target_percentage','expected_entitlement_percentage'
    )),
  base_quantity numeric(14,3) not null default 0 check (base_quantity >= 0),
  base_rate numeric(14,2) not null default 0 check (base_rate >= 0),
  base_amount numeric(14,2) not null default 0 check (base_amount >= 0),
  percentage numeric(8,4) not null default 0 check (percentage >= 0),
  amount numeric(14,2) not null check (amount > 0),
  status text not null default 'draft'
    check (status in ('draft','approved','paid','settled','cancelled')),
  reason text,
  created_by uuid references public.profiles(id),
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  paid_at timestamptz,
  settled_at timestamptz,
  created_at timestamptz not null default now(),
  unique(project_id, individual_id, advance_no)
);

create index if not exists idx_project_rewards_project
  on public.project_rewards(project_id, reward_date desc);

create index if not exists idx_transport_project
  on public.transport_entitlements(project_id, transport_date desc);

create index if not exists idx_advances_project
  on public.project_advances(project_id, advance_date desc);

-- =====================================================================
-- 7. FINANCIAL LEDGER / DOCUMENTS / SETTLEMENTS
-- =====================================================================

create table if not exists public.financial_ledger (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  individual_id uuid not null references public.individuals(id) on delete restrict,
  assignment_id uuid references public.assignments(id) on delete set null,

  entry_type text not null
    check (entry_type in (
      'fieldwork','training','transport','reward','penalty','adjustment'
    )),
  source_type text,
  source_id uuid,
  source_key text not null,

  quantity numeric(16,4) not null default 0,
  rate numeric(16,4) not null default 0,
  factor numeric(16,6) not null default 1,
  amount numeric(16,2) not null, -- signed: penalty is negative

  period_from date,
  period_to date,
  description text,

  status text not null default 'calculated'
    check (status in (
      'calculated','reviewed','approved','posted','paid','cancelled'
    )),

  created_by uuid references public.profiles(id),
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  unique(source_key)
);

create index if not exists idx_financial_ledger_project
  on public.financial_ledger(project_id, status, entry_type);

create index if not exists idx_financial_ledger_individual
  on public.financial_ledger(individual_id, project_id);

create table if not exists public.financial_documents (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  training_event_id uuid references public.training_events(id) on delete set null,
  document_type text not null
    check (document_type in (
      'training_reward','advance','settlement','other'
    )),
  employee_type text
    check (
      employee_type is null
      or employee_type in ('internal','external','outsourced')
    ),
  document_number text not null unique,
  revision_no integer not null default 0,
  status text not null default 'draft'
    check (status in ('draft','approved','issued','superseded','cancelled')),
  total_people integer not null default 0,
  total_amount numeric(16,2) not null default 0,
  issued_by uuid references public.profiles(id),
  issued_at timestamptz,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.financial_document_lines (
  id uuid primary key default gen_random_uuid(),
  document_id uuid not null references public.financial_documents(id) on delete cascade,
  individual_id uuid references public.individuals(id) on delete set null,

  full_name_snapshot text not null,
  job_title_snapshot text,
  worker_code_snapshot text,
  project_slot_code_snapshot text,
  national_id_snapshot text,
  contract_type_snapshot text,

  quantity numeric(16,4) not null default 0,
  rate numeric(16,4) not null default 0,
  amount numeric(16,2) not null default 0,
  notes text,
  line_no integer not null,
  unique(document_id, line_no)
);

create index if not exists idx_financial_documents_project
  on public.financial_documents(project_id, created_at desc);

create table if not exists public.financial_settlements (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  individual_id uuid not null references public.individuals(id) on delete restrict,

  entitlement_total numeric(16,2) not null default 0,
  advances_total numeric(16,2) not null default 0,
  payments_total numeric(16,2) not null default 0,
  net_due numeric(16,2) not null default 0,

  status text not null default 'draft'
    check (status in ('draft','reviewed','approved','settled','cancelled')),
  snapshot_at timestamptz not null default now(),
  created_by uuid references public.profiles(id),
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  notes text,
  unique(project_id, individual_id)
);

-- =====================================================================
-- 8. BUSINESS RPCs
-- =====================================================================

-- 8.1 Log a project event
create or replace function public.log_project_event_v11(
  p_project_id uuid,
  p_event_type text,
  p_entity_type text,
  p_entity_id uuid,
  p_title text,
  p_details jsonb default '{}'::jsonb
)
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_id bigint;
begin
  if not public.can_access_project_v11(p_project_id) then
    raise exception 'غير مصرح لك بالوصول إلى المشروع';
  end if;

  insert into public.project_events(
    project_id,event_type,entity_type,entity_id,title,details,actor_id
  )
  values(
    p_project_id,p_event_type,p_entity_type,p_entity_id,p_title,
    coalesce(p_details,'{}'::jsonb),auth.uid()
  )
  returning id into v_id;

  return v_id;
end;
$$;

-- 8.2 Approve an execution balance
create or replace function public.approve_execution_balance_v11(p_balance_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_project_id uuid;
begin
  select project_id into v_project_id
  from public.execution_balances
  where id = p_balance_id;

  if v_project_id is null then
    raise exception 'رصيد التنفيذ غير موجود';
  end if;

  if not public.can_operate_project_v11(v_project_id) then
    raise exception 'غير مصرح لك باعتماد رصيد التنفيذ';
  end if;

  update public.execution_balances
  set status='approved',
      approved_by=auth.uid(),
      approved_at=now(),
      updated_at=now()
  where id=p_balance_id
    and status <> 'cancelled';

  perform public.log_project_event_v11(
    v_project_id,'execution_approved','execution_balance',p_balance_id,
    'اعتماد رصيد تنفيذ','{}'::jsonb
  );
end;
$$;

-- 8.3 Quality incident confirmation + automatic penalty ledger entry
create or replace function public.approve_quality_incident_v11(
  p_incident_id uuid,
  p_review_note text default null
)
returns numeric
language plpgsql
security definer
set search_path = ''
as $$
declare
  q public.quality_incidents%rowtype;
  v_penalty numeric(14,2);
begin
  select * into q
  from public.quality_incidents
  where id = p_incident_id
  for update;

  if not found then
    raise exception 'خطأ الجودة غير موجود';
  end if;

  if not public.can_manage_project_finance_v11(q.project_id) then
    raise exception 'اعتماد الأثر المالي متاح لمسؤول المشروع/المشرف العام فقط';
  end if;

  v_penalty :=
    case q.financial_effect_type
      when 'none' then 0
      when 'fixed' then q.financial_value
      when 'percentage' then round(q.financial_base_amount * q.financial_value / 100.0, 2)
      when 'per_unit' then round(q.financial_quantity * q.financial_value, 2)
      else 0
    end;

  update public.quality_incidents
  set status='confirmed',
      calculated_penalty=v_penalty,
      reviewed_by=auth.uid(),
      reviewed_at=now(),
      approved_by=auth.uid(),
      approved_at=now(),
      review_note=p_review_note,
      updated_at=now()
  where id=p_incident_id;

  if v_penalty > 0 then
    insert into public.financial_ledger(
      project_id,individual_id,assignment_id,
      entry_type,source_type,source_id,source_key,
      quantity,rate,factor,amount,description,status,
      created_by,approved_by,approved_at
    )
    values(
      q.project_id,q.individual_id,q.assignment_id,
      'penalty','quality_incident',q.id,
      'quality:'||q.id::text,
      case when q.financial_effect_type='per_unit' then q.financial_quantity else 1 end,
      q.financial_value,1,-v_penalty,
      'جزاء جودة: '||q.category,
      'approved',
      auth.uid(),auth.uid(),now()
    )
    on conflict(source_key) do update
    set amount=excluded.amount,
        rate=excluded.rate,
        quantity=excluded.quantity,
        status='approved',
        approved_by=auth.uid(),
        approved_at=now(),
        updated_at=now();
  end if;

  perform public.log_project_event_v11(
    q.project_id,'quality_confirmed','quality_incident',q.id,
    'اعتماد خطأ جودة',
    jsonb_build_object('penalty',v_penalty)
  );

  return v_penalty;
end;
$$;

-- 8.4 Calculate training entitlements
create or replace function public.recalculate_training_event_v11(p_event_id uuid)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  te public.training_events%rowtype;
  v_count integer;
begin
  select * into te
  from public.training_events
  where id=p_event_id
  for update;

  if not found then
    raise exception 'العملية التدريبية غير موجودة';
  end if;

  if not public.can_manage_project_finance_v11(te.project_id) then
    raise exception 'غير مصرح لك بحساب مكافآت التدريب';
  end if;

  update public.training_participants tp
  set
    applied_rate = coalesce((
      select tr.amount
      from public.training_financial_rates tr
      where tr.project_id=te.project_id
        and tr.training_role=tp.training_role
        and tr.status='active'
        and (tr.training_event_id=te.id or tr.training_event_id is null)
      order by
        case when tr.training_event_id=te.id then 0 else 1 end,
        tr.created_at desc
      limit 1
    ),0),
    entitlement_amount =
      case
        when tp.participant_status <> 'eligible' then 0
        when coalesce((
          select tr.calc_basis
          from public.training_financial_rates tr
          where tr.project_id=te.project_id
            and tr.training_role=tp.training_role
            and tr.status='active'
            and (tr.training_event_id=te.id or tr.training_event_id is null)
          order by
            case when tr.training_event_id=te.id then 0 else 1 end,
            tr.created_at desc
          limit 1
        ),'fixed')='fixed'
        then coalesce((
          select tr.amount
          from public.training_financial_rates tr
          where tr.project_id=te.project_id
            and tr.training_role=tp.training_role
            and tr.status='active'
            and (tr.training_event_id=te.id or tr.training_event_id is null)
          order by
            case when tr.training_event_id=te.id then 0 else 1 end,
            tr.created_at desc
          limit 1
        ),0)
        else round(
          tp.attendance_days * coalesce((
            select tr.amount
            from public.training_financial_rates tr
            where tr.project_id=te.project_id
              and tr.training_role=tp.training_role
              and tr.status='active'
              and (tr.training_event_id=te.id or tr.training_event_id is null)
            order by
              case when tr.training_event_id=te.id then 0 else 1 end,
              tr.created_at desc
            limit 1
          ),0),2
        )
      end,
    updated_at=now()
  where tp.training_event_id=te.id;

  get diagnostics v_count = row_count;

  update public.training_events
  set status = case
    when status in ('draft','active','closed') then 'financial_review'
    else status
  end
  where id=te.id;

  perform public.log_project_event_v11(
    te.project_id,'training_calculated','training_event',te.id,
    'احتساب مكافآت التدريب',
    jsonb_build_object('participants',v_count)
  );

  return v_count;
end;
$$;

-- 8.5 Post training entitlements to ledger
create or replace function public.post_training_event_entitlements_v11(p_event_id uuid)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  te public.training_events%rowtype;
  v_count integer := 0;
begin
  select * into te
  from public.training_events
  where id=p_event_id
  for update;

  if not found then
    raise exception 'العملية التدريبية غير موجودة';
  end if;

  if not public.can_manage_project_finance_v11(te.project_id) then
    raise exception 'غير مصرح لك بترحيل مكافآت التدريب';
  end if;

  if te.status not in ('financial_review','approved','posted') then
    raise exception 'يجب احتساب وإغلاق العملية التدريبية أولاً';
  end if;

  insert into public.financial_ledger(
    project_id,individual_id,assignment_id,
    entry_type,source_type,source_id,source_key,
    quantity,rate,factor,amount,
    period_from,period_to,description,status,
    created_by,approved_by,approved_at
  )
  select
    te.project_id,tp.individual_id,tp.assignment_id,
    'training','training_participant',tp.id,
    'training:'||tp.id::text,
    tp.attendance_days,tp.applied_rate,1,tp.entitlement_amount,
    te.start_date,te.end_date,
    'مكافأة تدريب: '||te.title,
    'approved',
    auth.uid(),auth.uid(),now()
  from public.training_participants tp
  where tp.training_event_id=te.id
    and tp.participant_status='eligible'
    and tp.entitlement_amount > 0
  on conflict(source_key) do update
  set amount=excluded.amount,
      quantity=excluded.quantity,
      rate=excluded.rate,
      status='approved',
      approved_by=auth.uid(),
      approved_at=now(),
      updated_at=now();

  get diagnostics v_count = row_count;

  update public.training_events
  set status='posted'
  where id=te.id;

  perform public.log_project_event_v11(
    te.project_id,'training_posted','training_event',te.id,
    'ترحيل مكافآت التدريب إلى المالية',
    jsonb_build_object('ledger_entries',v_count)
  );

  return v_count;
end;
$$;

-- 8.6 Issue the three training reward statements
create or replace function public.issue_training_reward_documents_v11(
  p_event_id uuid,
  p_reissue boolean default false
)
returns table(employee_type text, document_id uuid, document_number text)
language plpgsql
security definer
set search_path = ''
as $$
declare
  te public.training_events%rowtype;
  v_type text;
  v_suffix text;
  v_revision integer;
  v_doc_id uuid;
  v_doc_no text;
begin
  select * into te
  from public.training_events
  where id=p_event_id
  for update;

  if not found then
    raise exception 'العملية التدريبية غير موجودة';
  end if;

  if not public.can_manage_project_finance_v11(te.project_id) then
    raise exception 'غير مصرح لك بإصدار مستندات التدريب';
  end if;

  if te.status <> 'posted' then
    raise exception 'يجب ترحيل مكافآت التدريب للمالية قبل إصدار البيانات';
  end if;

  if exists(
    select 1 from public.financial_documents fd
    where fd.training_event_id=te.id
      and fd.document_type='training_reward'
      and fd.status='issued'
  ) and not p_reissue then
    raise exception 'تم إصدار بيانات هذه العملية بالفعل؛ استخدم إعادة الإصدار لإنشاء Revision جديد';
  end if;

  if p_reissue then
    update public.financial_documents
    set status='superseded'
    where training_event_id=te.id
      and document_type='training_reward'
      and status='issued';
  end if;

  select coalesce(max(revision_no),-1)+1
  into v_revision
  from public.financial_documents
  where training_event_id=te.id
    and document_type='training_reward';

  foreach v_type in array array['internal'::text,'external'::text,'outsourced'::text]
  loop
    v_suffix :=
      case v_type
        when 'internal' then 'INT'
        when 'external' then 'EXT'
        else 'OUT'
      end;

    v_doc_no :=
      'TRN-'||to_char(current_date,'YYYY')||'-'||
      coalesce(
        nullif(regexp_replace(te.event_code,'[^A-Za-z0-9_-]','','g'),''),
        substr(te.id::text,1,8)
      )||'-'||v_suffix||'-R'||v_revision::text;

    insert into public.financial_documents(
      project_id,training_event_id,document_type,employee_type,
      document_number,revision_no,status,issued_by,issued_at
    )
    values(
      te.project_id,te.id,'training_reward',v_type,
      v_doc_no,v_revision,'issued',auth.uid(),now()
    )
    returning id into v_doc_id;

    insert into public.financial_document_lines(
      document_id,individual_id,
      full_name_snapshot,job_title_snapshot,worker_code_snapshot,
      project_slot_code_snapshot,national_id_snapshot,contract_type_snapshot,
      quantity,rate,amount,line_no
    )
    select
      v_doc_id,tp.individual_id,
      coalesce(tp.full_name_snapshot,i.full_name),
      tp.job_title_snapshot,
      coalesce(tp.worker_code_snapshot,i.internal_employee_code),
      tp.project_slot_code_snapshot,
      coalesce(tp.national_id_snapshot,i.national_id),
      coalesce(tp.contract_type_snapshot,i.contract_type),
      tp.attendance_days,tp.applied_rate,tp.entitlement_amount,
      row_number() over(order by coalesce(tp.full_name_snapshot,i.full_name))
    from public.training_participants tp
    join public.individuals i on i.id=tp.individual_id
    where tp.training_event_id=te.id
      and tp.participant_status='eligible'
      and tp.entitlement_amount > 0
      and coalesce(tp.contract_type_snapshot,i.contract_type)=v_type;

    update public.financial_documents fd
    set
      total_people = x.cnt,
      total_amount = x.total
    from (
      select
        count(*)::integer as cnt,
        coalesce(sum(amount),0)::numeric(16,2) as total
      from public.financial_document_lines
      where document_id=v_doc_id
    ) x
    where fd.id=v_doc_id;

    employee_type := v_type;
    document_id := v_doc_id;
    document_number := v_doc_no;
    return next;
  end loop;

  perform public.log_project_event_v11(
    te.project_id,'training_documents_issued','training_event',te.id,
    'إصدار بيانات مكافآت التدريب',
    jsonb_build_object('revision',v_revision)
  );
end;
$$;

-- 8.7 Reward create/approve
create or replace function public.create_project_reward_v11(
  p_project_id uuid,
  p_individual_id uuid,
  p_assignment_id uuid,
  p_reward_type text,
  p_description text,
  p_calc_type text,
  p_base_amount numeric default 0,
  p_percentage numeric default 0,
  p_quantity numeric default 0,
  p_rate numeric default 0,
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_id uuid;
  v_amount numeric(14,2);
begin
  if not public.can_manage_project_finance_v11(p_project_id) then
    raise exception 'غير مصرح لك بإنشاء مكافأة';
  end if;

  v_amount :=
    case p_calc_type
      when 'fixed' then round(coalesce(p_base_amount,0),2)
      when 'percentage' then round(coalesce(p_base_amount,0)*coalesce(p_percentage,0)/100.0,2)
      when 'per_unit' then round(coalesce(p_quantity,0)*coalesce(p_rate,0),2)
      else null
    end;

  if v_amount is null or v_amount <= 0 then
    raise exception 'قيمة المكافأة غير صحيحة';
  end if;

  insert into public.project_rewards(
    project_id,individual_id,assignment_id,reward_type,description,
    calc_type,base_amount,percentage,quantity,rate,amount,
    status,created_by,notes
  )
  values(
    p_project_id,p_individual_id,p_assignment_id,p_reward_type,p_description,
    p_calc_type,coalesce(p_base_amount,0),coalesce(p_percentage,0),
    coalesce(p_quantity,0),coalesce(p_rate,0),v_amount,
    'draft',auth.uid(),p_notes
  )
  returning id into v_id;

  return v_id;
end;
$$;

create or replace function public.approve_project_reward_v11(p_reward_id uuid)
returns numeric
language plpgsql
security definer
set search_path = ''
as $$
declare
  r public.project_rewards%rowtype;
begin
  select * into r
  from public.project_rewards
  where id=p_reward_id
  for update;

  if not found then
    raise exception 'المكافأة غير موجودة';
  end if;

  if not public.can_manage_project_finance_v11(r.project_id) then
    raise exception 'غير مصرح لك باعتماد المكافأة';
  end if;

  update public.project_rewards
  set status='approved',approved_by=auth.uid(),approved_at=now()
  where id=r.id;

  insert into public.financial_ledger(
    project_id,individual_id,assignment_id,
    entry_type,source_type,source_id,source_key,
    quantity,rate,factor,amount,
    period_from,period_to,description,status,
    created_by,approved_by,approved_at
  )
  values(
    r.project_id,r.individual_id,r.assignment_id,
    'reward','project_reward',r.id,'reward:'||r.id::text,
    case when r.calc_type='per_unit' then r.quantity else 1 end,
    case when r.calc_type='per_unit' then r.rate else r.amount end,
    1,r.amount,r.reward_date,r.reward_date,
    r.description,'approved',auth.uid(),auth.uid(),now()
  )
  on conflict(source_key) do update
  set amount=excluded.amount,status='approved',
      approved_by=auth.uid(),approved_at=now(),updated_at=now();

  return r.amount;
end;
$$;

-- 8.8 Transport create/approve
create or replace function public.create_transport_entitlement_v11(
  p_project_id uuid,
  p_individual_id uuid,
  p_assignment_id uuid,
  p_transport_date date,
  p_location text,
  p_calc_type text,
  p_quantity numeric,
  p_rate numeric,
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_id uuid;
  v_amount numeric(14,2);
begin
  if not public.can_manage_project_finance_v11(p_project_id) then
    raise exception 'غير مصرح لك بإضافة مقابل انتقال';
  end if;

  v_amount :=
    case
      when p_calc_type='fixed' then round(coalesce(p_rate,0),2)
      else round(coalesce(p_quantity,0)*coalesce(p_rate,0),2)
    end;

  if v_amount <= 0 then
    raise exception 'قيمة مقابل الانتقال غير صحيحة';
  end if;

  insert into public.transport_entitlements(
    project_id,individual_id,assignment_id,transport_date,
    location_description,calc_type,quantity,rate,amount,
    status,created_by,notes
  )
  values(
    p_project_id,p_individual_id,p_assignment_id,coalesce(p_transport_date,current_date),
    p_location,p_calc_type,coalesce(p_quantity,1),coalesce(p_rate,0),v_amount,
    'draft',auth.uid(),p_notes
  )
  returning id into v_id;

  return v_id;
end;
$$;

create or replace function public.approve_transport_entitlement_v11(p_transport_id uuid)
returns numeric
language plpgsql
security definer
set search_path = ''
as $$
declare
  t public.transport_entitlements%rowtype;
begin
  select * into t
  from public.transport_entitlements
  where id=p_transport_id
  for update;

  if not found then
    raise exception 'استحقاق الانتقال غير موجود';
  end if;

  if not public.can_manage_project_finance_v11(t.project_id) then
    raise exception 'غير مصرح لك باعتماد مقابل الانتقال';
  end if;

  update public.transport_entitlements
  set status='approved',approved_by=auth.uid(),approved_at=now()
  where id=t.id;

  insert into public.financial_ledger(
    project_id,individual_id,assignment_id,
    entry_type,source_type,source_id,source_key,
    quantity,rate,factor,amount,
    period_from,period_to,description,status,
    created_by,approved_by,approved_at
  )
  values(
    t.project_id,t.individual_id,t.assignment_id,
    'transport','transport_entitlement',t.id,'transport:'||t.id::text,
    t.quantity,t.rate,1,t.amount,
    t.transport_date,t.transport_date,
    'مقابل انتقال'||case when t.location_description is not null then ': '||t.location_description else '' end,
    'approved',auth.uid(),auth.uid(),now()
  )
  on conflict(source_key) do update
  set amount=excluded.amount,quantity=excluded.quantity,rate=excluded.rate,
      status='approved',approved_by=auth.uid(),approved_at=now(),updated_at=now();

  return t.amount;
end;
$$;

-- 8.9 Advance create/approve/pay
create or replace function public.create_project_advance_v11(
  p_project_id uuid,
  p_individual_id uuid,
  p_assignment_id uuid,
  p_advance_type text,
  p_base_quantity numeric default 0,
  p_base_rate numeric default 0,
  p_base_amount numeric default 0,
  p_percentage numeric default 0,
  p_fixed_amount numeric default 0,
  p_reason text default null
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_id uuid;
  v_amount numeric(14,2);
  v_no integer;
begin
  if not public.can_manage_project_finance_v11(p_project_id) then
    raise exception 'غير مصرح لك بإنشاء دفعة تحت الحساب';
  end if;

  v_amount :=
    case p_advance_type
      when 'fixed' then round(coalesce(p_fixed_amount,0),2)
      when 'target_percentage' then
        round(coalesce(p_base_quantity,0)*coalesce(p_base_rate,0)*coalesce(p_percentage,0)/100.0,2)
      when 'expected_entitlement_percentage' then
        round(coalesce(p_base_amount,0)*coalesce(p_percentage,0)/100.0,2)
      else null
    end;

  if v_amount is null or v_amount <= 0 then
    raise exception 'قيمة الدفعة تحت الحساب غير صحيحة';
  end if;

  select coalesce(max(advance_no),0)+1
  into v_no
  from public.project_advances
  where project_id=p_project_id
    and individual_id=p_individual_id;

  insert into public.project_advances(
    project_id,individual_id,assignment_id,advance_no,advance_type,
    base_quantity,base_rate,base_amount,percentage,amount,
    status,reason,created_by
  )
  values(
    p_project_id,p_individual_id,p_assignment_id,v_no,p_advance_type,
    coalesce(p_base_quantity,0),coalesce(p_base_rate,0),coalesce(p_base_amount,0),
    coalesce(p_percentage,0),v_amount,'draft',p_reason,auth.uid()
  )
  returning id into v_id;

  return v_id;
end;
$$;

create or replace function public.approve_project_advance_v11(p_advance_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  a public.project_advances%rowtype;
begin
  select * into a
  from public.project_advances
  where id=p_advance_id
  for update;

  if not found then
    raise exception 'الدفعة غير موجودة';
  end if;

  if not public.can_manage_project_finance_v11(a.project_id) then
    raise exception 'غير مصرح لك باعتماد الدفعة';
  end if;

  update public.project_advances
  set status='approved',approved_by=auth.uid(),approved_at=now()
  where id=a.id and status='draft';
end;
$$;

create or replace function public.mark_project_advance_paid_v11(p_advance_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  a public.project_advances%rowtype;
begin
  select * into a
  from public.project_advances
  where id=p_advance_id
  for update;

  if not found then
    raise exception 'الدفعة غير موجودة';
  end if;

  if not public.can_manage_project_finance_v11(a.project_id) then
    raise exception 'غير مصرح لك بإثبات صرف الدفعة';
  end if;

  if a.status <> 'approved' then
    raise exception 'يجب اعتماد الدفعة أولاً';
  end if;

  update public.project_advances
  set status='paid',paid_at=now()
  where id=a.id;
end;
$$;

-- 8.10 Fieldwork entitlement engine
create or replace function public.recalculate_fieldwork_entitlements_v11(
  p_project_id uuid,
  p_period_from date,
  p_period_to date
)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_unconfigured integer;
  v_count integer := 0;
begin
  if not public.can_manage_project_finance_v11(p_project_id) then
    raise exception 'غير مصرح لك بحساب استحقاقات التنفيذ';
  end if;

  if p_period_from is null or p_period_to is null or p_period_to < p_period_from then
    raise exception 'الفترة المالية غير صحيحة';
  end if;

  -- Block calculations when partial/excluded balances exist without a
  -- project-approved financial factor.
  select count(*) into v_unconfigured
  from public.execution_status_factors f
  where f.project_id=p_project_id
    and f.is_configured=false
    and (
      (f.status_key='partial' and exists(
        select 1 from public.execution_balances eb
        where eb.project_id=p_project_id
          and eb.status='approved'
          and eb.balance_date between p_period_from and p_period_to
          and eb.partial_count > 0
      ))
      or
      (f.status_key='excluded' and exists(
        select 1 from public.execution_balances eb
        where eb.project_id=p_project_id
          and eb.status='approved'
          and eb.balance_date between p_period_from and p_period_to
          and eb.excluded_count > 0
      ))
    );

  if v_unconfigured > 0 then
    raise exception 'يجب تحديد المعامل المالي للاستيفاء الجزئي/المستبعد قبل الحساب';
  end if;

  -- Remove only recalculable, unapproved fieldwork rows for this period.
  delete from public.financial_ledger
  where project_id=p_project_id
    and entry_type='fieldwork'
    and period_from=p_period_from
    and period_to=p_period_to
    and status in ('calculated','reviewed');

  with factors as (
    select
      max(factor) filter(where status_key='full') as full_f,
      max(factor) filter(where status_key='partial') as partial_f,
      max(factor) filter(where status_key='excluded') as excluded_f,
      max(factor) filter(where status_key='in_progress') as in_progress_f,
      max(factor) filter(where status_key='not_started') as not_started_f
    from public.execution_status_factors
    where project_id=p_project_id
  ),
  active_assignments as (
    select
      a.id as assignment_id,
      a.individual_id,
      a.role,
      a.slot_id,
      ss.parent_slot_id
    from public.assignments a
    join public.structure_slots ss on ss.id=a.slot_id
    where a.project_id=p_project_id
      and a.status in ('active','ended')
      and a.start_date <= p_period_to
      and coalesce(a.end_date,'infinity'::date) >= p_period_from
  ),
  researcher_equiv as (
    select
      eb.assignment_id,
      sum(
        eb.full_count * coalesce(f.full_f,0) +
        eb.partial_count * coalesce(f.partial_f,0) +
        eb.excluded_count * coalesce(f.excluded_f,0) +
        eb.in_progress_count * coalesce(f.in_progress_f,0) +
        eb.not_started_count * coalesce(f.not_started_f,0)
      )::numeric(16,4) as qty,
      count(distinct eb.balance_date)::numeric as work_days
    from public.execution_balances eb
    cross join factors f
    where eb.project_id=p_project_id
      and eb.status='approved'
      and eb.balance_date between p_period_from and p_period_to
    group by eb.assignment_id
  ),
  assignment_scope as (
    -- researcher: own balances
    select
      aa.assignment_id, aa.individual_id, aa.role,
      coalesce(re.qty,0) as qty,
      coalesce(re.work_days,0) as work_days
    from active_assignments aa
    left join researcher_equiv re on re.assignment_id=aa.assignment_id
    where aa.role='researcher'

    union all

    -- reviewer: balances of researchers whose slot parent is reviewer slot
    select
      rv.assignment_id,rv.individual_id,rv.role,
      coalesce(sum(re.qty),0),
      coalesce(max(re.work_days),0)
    from active_assignments rv
    left join public.structure_slots child
      on child.parent_slot_id=rv.slot_id
     and child.project_id=p_project_id
     and child.role='researcher'
    left join active_assignments ra
      on ra.slot_id=child.id and ra.role='researcher'
    left join researcher_equiv re
      on re.assignment_id=ra.assignment_id
    where rv.role='reviewer'
    group by rv.assignment_id,rv.individual_id,rv.role

    union all

    -- supervisor: balances of researchers under reviewer children
    select
      sp.assignment_id,sp.individual_id,sp.role,
      coalesce(sum(re.qty),0),
      coalesce(max(re.work_days),0)
    from active_assignments sp
    left join public.structure_slots rev
      on rev.parent_slot_id=sp.slot_id
     and rev.project_id=p_project_id
     and rev.role='reviewer'
    left join public.structure_slots res
      on res.parent_slot_id=rev.id
     and res.project_id=p_project_id
     and res.role='researcher'
    left join active_assignments ra
      on ra.slot_id=res.id and ra.role='researcher'
    left join researcher_equiv re
      on re.assignment_id=ra.assignment_id
    where sp.role='supervisor'
    group by sp.assignment_id,sp.individual_id,sp.role

    union all

    -- coordinator: project-wide equivalent volume
    select
      co.assignment_id,co.individual_id,co.role,
      coalesce((select sum(qty) from researcher_equiv),0),
      coalesce((select max(work_days) from researcher_equiv),0)
    from active_assignments co
    where co.role='coordinator'
  ),
  chosen_rates as (
    select distinct on (pr.role)
      pr.role,pr.rate_type,pr.amount
    from public.project_rates pr
    where pr.project_id=p_project_id
      and pr.status='active'
    order by pr.role,pr.created_at desc nulls last
  )
  insert into public.financial_ledger(
    project_id,individual_id,assignment_id,
    entry_type,source_type,source_id,source_key,
    quantity,rate,factor,amount,
    period_from,period_to,description,status,created_by
  )
  select
    p_project_id,s.individual_id,s.assignment_id,
    'fieldwork','assignment',s.assignment_id,
    'fieldwork:'||s.assignment_id::text||':'||p_period_from::text||':'||p_period_to::text,
    case
      when r.rate_type='daily' then s.work_days
      when r.rate_type='fixed' then 1
      else s.qty
    end,
    r.amount,1,
    round(
      case
        when r.rate_type='daily' then s.work_days * r.amount
        when r.rate_type='fixed' then r.amount
        else s.qty * r.amount
      end
    ,2),
    p_period_from,p_period_to,
    'استحقاق تنفيذ ميداني — '||s.role,
    'calculated',auth.uid()
  from assignment_scope s
  join chosen_rates r on r.role=s.role
  where
    case
      when r.rate_type='daily' then s.work_days
      when r.rate_type='fixed' then 1
      else s.qty
    end > 0
  on conflict(source_key) do update
  set quantity=excluded.quantity,
      rate=excluded.rate,
      amount=excluded.amount,
      status=case
        when public.financial_ledger.status in ('approved','posted','paid')
        then public.financial_ledger.status
        else 'calculated'
      end,
      updated_at=now();

  get diagnostics v_count = row_count;

  perform public.log_project_event_v11(
    p_project_id,'fieldwork_calculated','financial_ledger',null,
    'احتساب استحقاقات التنفيذ',
    jsonb_build_object(
      'period_from',p_period_from,
      'period_to',p_period_to,
      'entries',v_count
    )
  );

  return v_count;
end;
$$;

create or replace function public.approve_calculated_fieldwork_v11(
  p_project_id uuid,
  p_period_from date,
  p_period_to date
)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_count integer;
begin
  if not public.can_manage_project_finance_v11(p_project_id) then
    raise exception 'غير مصرح لك باعتماد استحقاقات التنفيذ';
  end if;

  update public.financial_ledger
  set status='approved',
      approved_by=auth.uid(),
      approved_at=now(),
      updated_at=now()
  where project_id=p_project_id
    and entry_type='fieldwork'
    and period_from=p_period_from
    and period_to=p_period_to
    and status in ('calculated','reviewed');

  get diagnostics v_count=row_count;
  return v_count;
end;
$$;

-- 8.11 Final settlement snapshot
create or replace function public.snapshot_project_settlements_v11(p_project_id uuid)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_count integer;
begin
  if not public.can_manage_project_finance_v11(p_project_id) then
    raise exception 'غير مصرح لك بإعداد المقاصة';
  end if;

  insert into public.financial_settlements(
    project_id,individual_id,
    entitlement_total,advances_total,payments_total,net_due,
    status,snapshot_at,created_by
  )
  select
    pos.project_id,pos.individual_id,
    pos.entitlement_total,pos.advances_total,pos.payments_total,pos.net_due,
    'draft',now(),auth.uid()
  from public.v_project_financial_position_v11 pos
  where pos.project_id=p_project_id
  on conflict(project_id,individual_id) do update
  set entitlement_total=excluded.entitlement_total,
      advances_total=excluded.advances_total,
      payments_total=excluded.payments_total,
      net_due=excluded.net_due,
      status=case
        when public.financial_settlements.status in ('approved','settled')
        then public.financial_settlements.status
        else 'draft'
      end,
      snapshot_at=now(),
      created_by=auth.uid();

  get diagnostics v_count=row_count;

  perform public.log_project_event_v11(
    p_project_id,'settlement_snapshot','financial_settlement',null,
    'إعداد مقاصة وتسوية المشروع',
    jsonb_build_object('workers',v_count)
  );

  return v_count;
end;
$$;

-- =====================================================================
-- 9. VIEWS
-- =====================================================================

create or replace view public.v_execution_project_summary_v11
with (security_invoker = true)
as
select
  eb.project_id,
  sum(eb.target_count)::bigint as target_count,
  sum(eb.full_count)::bigint as full_count,
  sum(eb.partial_count)::bigint as partial_count,
  sum(eb.excluded_count)::bigint as excluded_count,
  sum(eb.in_progress_count)::bigint as in_progress_count,
  sum(eb.not_started_count)::bigint as not_started_count,
  sum(
    eb.full_count + eb.partial_count + eb.excluded_count
  )::bigint as closed_balance,
  max(eb.balance_date) as last_balance_date
from public.execution_balances eb
where eb.status='approved'
group by eb.project_id;

create or replace view public.v_project_financial_position_v11
with (security_invoker = true)
as
with people as (
  select distinct project_id,individual_id
  from public.assignments
  union
  select distinct project_id,individual_id
  from public.financial_ledger
  union
  select distinct project_id,individual_id
  from public.project_advances
  union
  select distinct project_id,individual_id
  from public.payments
),
ledger as (
  select
    project_id,individual_id,
    sum(amount) filter(where status in ('approved','posted','paid')) as entitlement_total,
    sum(amount) filter(where status in ('calculated','reviewed')) as pending_calculation
  from public.financial_ledger
  group by project_id,individual_id
),
adv as (
  select project_id,individual_id,
    sum(amount) filter(where status in ('paid','settled')) as advances_total
  from public.project_advances
  group by project_id,individual_id
),
pay as (
  select project_id,individual_id,
    sum(amount) filter(where status='paid') as payments_total
  from public.payments
  group by project_id,individual_id
)
select
  pe.project_id,
  pe.individual_id,
  i.full_name,
  i.national_id,
  i.contract_type,
  coalesce(l.entitlement_total,0)::numeric(16,2) as entitlement_total,
  coalesce(l.pending_calculation,0)::numeric(16,2) as pending_calculation,
  coalesce(a.advances_total,0)::numeric(16,2) as advances_total,
  coalesce(p.payments_total,0)::numeric(16,2) as payments_total,
  (
    coalesce(l.entitlement_total,0)
    - coalesce(a.advances_total,0)
    - coalesce(p.payments_total,0)
  )::numeric(16,2) as net_due
from people pe
join public.individuals i on i.id=pe.individual_id
left join ledger l
  on l.project_id=pe.project_id and l.individual_id=pe.individual_id
left join adv a
  on a.project_id=pe.project_id and a.individual_id=pe.individual_id
left join pay p
  on p.project_id=pe.project_id and p.individual_id=pe.individual_id;

-- =====================================================================
-- 10. RLS
-- =====================================================================

alter table public.platform_features enable row level security;
alter table public.project_versions enable row level security;
alter table public.project_members enable row level security;
alter table public.project_events enable row level security;
alter table public.execution_balances enable row level security;
alter table public.execution_status_factors enable row level security;
alter table public.quality_incidents enable row level security;
alter table public.training_events enable row level security;
alter table public.training_financial_rates enable row level security;
alter table public.training_participants enable row level security;
alter table public.project_rewards enable row level security;
alter table public.transport_entitlements enable row level security;
alter table public.project_advances enable row level security;
alter table public.financial_ledger enable row level security;
alter table public.financial_documents enable row level security;
alter table public.financial_document_lines enable row level security;
alter table public.financial_settlements enable row level security;

-- Feature flag: authenticated read, admin update.
drop policy if exists v11_feature_read on public.platform_features;
create policy v11_feature_read
on public.platform_features for select to authenticated
using (true);

drop policy if exists v11_feature_admin on public.platform_features;
create policy v11_feature_admin
on public.platform_features for all to authenticated
using (public.my_role()='admin')
with check (public.my_role()='admin');

-- Generic project-scoped tables
drop policy if exists v11_project_versions_read on public.project_versions;
create policy v11_project_versions_read
on public.project_versions for select to authenticated
using (public.can_access_project_v11(project_id));

drop policy if exists v11_project_versions_write on public.project_versions;
create policy v11_project_versions_write
on public.project_versions for all to authenticated
using (public.can_manage_project_finance_v11(project_id))
with check (public.can_manage_project_finance_v11(project_id));

drop policy if exists v11_project_members_read on public.project_members;
create policy v11_project_members_read
on public.project_members for select to authenticated
using (public.can_access_project_v11(project_id));

drop policy if exists v11_project_members_write on public.project_members;
create policy v11_project_members_write
on public.project_members for all to authenticated
using (public.can_manage_project_finance_v11(project_id))
with check (public.can_manage_project_finance_v11(project_id));

drop policy if exists v11_project_events_read on public.project_events;
create policy v11_project_events_read
on public.project_events for select to authenticated
using (public.can_access_project_v11(project_id));

drop policy if exists v11_project_events_insert on public.project_events;
create policy v11_project_events_insert
on public.project_events for insert to authenticated
with check (public.can_access_project_v11(project_id));

-- Execution
drop policy if exists v11_execution_read on public.execution_balances;
create policy v11_execution_read
on public.execution_balances for select to authenticated
using (public.can_access_project_v11(project_id));

drop policy if exists v11_execution_insert on public.execution_balances;
create policy v11_execution_insert
on public.execution_balances for insert to authenticated
with check (public.can_operate_project_v11(project_id));

drop policy if exists v11_execution_update on public.execution_balances;
create policy v11_execution_update
on public.execution_balances for update to authenticated
using (public.can_operate_project_v11(project_id))
with check (public.can_operate_project_v11(project_id));

drop policy if exists v11_execution_delete on public.execution_balances;
create policy v11_execution_delete
on public.execution_balances for delete to authenticated
using (public.can_manage_project_finance_v11(project_id));

drop policy if exists v11_execution_factors_read on public.execution_status_factors;
create policy v11_execution_factors_read
on public.execution_status_factors for select to authenticated
using (public.can_access_project_v11(project_id));

drop policy if exists v11_execution_factors_write on public.execution_status_factors;
create policy v11_execution_factors_write
on public.execution_status_factors for all to authenticated
using (public.can_manage_project_finance_v11(project_id))
with check (public.can_manage_project_finance_v11(project_id));

-- Quality
drop policy if exists v11_quality_read on public.quality_incidents;
create policy v11_quality_read
on public.quality_incidents for select to authenticated
using (public.can_access_project_v11(project_id));

drop policy if exists v11_quality_insert on public.quality_incidents;
create policy v11_quality_insert
on public.quality_incidents for insert to authenticated
with check (public.can_operate_project_v11(project_id));

drop policy if exists v11_quality_update on public.quality_incidents;
create policy v11_quality_update
on public.quality_incidents for update to authenticated
using (public.can_operate_project_v11(project_id))
with check (public.can_operate_project_v11(project_id));

-- Training
drop policy if exists v11_training_events_read on public.training_events;
create policy v11_training_events_read
on public.training_events for select to authenticated
using (public.can_access_project_v11(project_id));

drop policy if exists v11_training_events_write on public.training_events;
create policy v11_training_events_write
on public.training_events for all to authenticated
using (public.can_manage_project_finance_v11(project_id))
with check (public.can_manage_project_finance_v11(project_id));

drop policy if exists v11_training_rates_read on public.training_financial_rates;
create policy v11_training_rates_read
on public.training_financial_rates for select to authenticated
using (public.can_read_project_finance_v11(project_id));

drop policy if exists v11_training_rates_write on public.training_financial_rates;
create policy v11_training_rates_write
on public.training_financial_rates for all to authenticated
using (public.can_manage_project_finance_v11(project_id))
with check (public.can_manage_project_finance_v11(project_id));

drop policy if exists v11_training_participants_read on public.training_participants;
create policy v11_training_participants_read
on public.training_participants for select to authenticated
using (
  exists(
    select 1 from public.training_events te
    where te.id=training_event_id
      and public.can_access_project_v11(te.project_id)
  )
);

drop policy if exists v11_training_participants_write on public.training_participants;
create policy v11_training_participants_write
on public.training_participants for all to authenticated
using (
  exists(
    select 1 from public.training_events te
    where te.id=training_event_id
      and public.can_manage_project_finance_v11(te.project_id)
  )
)
with check (
  exists(
    select 1 from public.training_events te
    where te.id=training_event_id
      and public.can_manage_project_finance_v11(te.project_id)
  )
);

-- Finance helper tables
drop policy if exists v11_rewards_read on public.project_rewards;
create policy v11_rewards_read
on public.project_rewards for select to authenticated
using (public.can_read_project_finance_v11(project_id));

drop policy if exists v11_rewards_write on public.project_rewards;
create policy v11_rewards_write
on public.project_rewards for all to authenticated
using (public.can_manage_project_finance_v11(project_id))
with check (public.can_manage_project_finance_v11(project_id));

drop policy if exists v11_transport_read on public.transport_entitlements;
create policy v11_transport_read
on public.transport_entitlements for select to authenticated
using (public.can_read_project_finance_v11(project_id));

drop policy if exists v11_transport_write on public.transport_entitlements;
create policy v11_transport_write
on public.transport_entitlements for all to authenticated
using (public.can_manage_project_finance_v11(project_id))
with check (public.can_manage_project_finance_v11(project_id));

drop policy if exists v11_advances_read on public.project_advances;
create policy v11_advances_read
on public.project_advances for select to authenticated
using (public.can_read_project_finance_v11(project_id));

drop policy if exists v11_advances_write on public.project_advances;
create policy v11_advances_write
on public.project_advances for all to authenticated
using (public.can_manage_project_finance_v11(project_id))
with check (public.can_manage_project_finance_v11(project_id));

drop policy if exists v11_ledger_read on public.financial_ledger;
create policy v11_ledger_read
on public.financial_ledger for select to authenticated
using (public.can_read_project_finance_v11(project_id));

drop policy if exists v11_ledger_write on public.financial_ledger;
create policy v11_ledger_write
on public.financial_ledger for all to authenticated
using (public.can_manage_project_finance_v11(project_id))
with check (public.can_manage_project_finance_v11(project_id));

drop policy if exists v11_documents_read on public.financial_documents;
create policy v11_documents_read
on public.financial_documents for select to authenticated
using (public.can_read_project_finance_v11(project_id));

drop policy if exists v11_documents_write on public.financial_documents;
create policy v11_documents_write
on public.financial_documents for all to authenticated
using (public.can_manage_project_finance_v11(project_id))
with check (public.can_manage_project_finance_v11(project_id));

drop policy if exists v11_document_lines_read on public.financial_document_lines;
create policy v11_document_lines_read
on public.financial_document_lines for select to authenticated
using (
  exists(
    select 1
    from public.financial_documents fd
    where fd.id=document_id
      and public.can_read_project_finance_v11(fd.project_id)
  )
);

drop policy if exists v11_document_lines_write on public.financial_document_lines;
create policy v11_document_lines_write
on public.financial_document_lines for all to authenticated
using (
  exists(
    select 1
    from public.financial_documents fd
    where fd.id=document_id
      and public.can_manage_project_finance_v11(fd.project_id)
  )
)
with check (
  exists(
    select 1
    from public.financial_documents fd
    where fd.id=document_id
      and public.can_manage_project_finance_v11(fd.project_id)
  )
);

drop policy if exists v11_settlements_read on public.financial_settlements;
create policy v11_settlements_read
on public.financial_settlements for select to authenticated
using (public.can_read_project_finance_v11(project_id));

drop policy if exists v11_settlements_write on public.financial_settlements;
create policy v11_settlements_write
on public.financial_settlements for all to authenticated
using (public.can_manage_project_finance_v11(project_id))
with check (public.can_manage_project_finance_v11(project_id));

-- =====================================================================
-- 11. GRANTS
-- =====================================================================

revoke all on table
  public.platform_features,
  public.project_versions,
  public.project_members,
  public.project_events,
  public.execution_balances,
  public.execution_status_factors,
  public.quality_incidents,
  public.training_events,
  public.training_financial_rates,
  public.training_participants,
  public.project_rewards,
  public.transport_entitlements,
  public.project_advances,
  public.financial_ledger,
  public.financial_documents,
  public.financial_document_lines,
  public.financial_settlements
from anon;

grant select,insert,update,delete on table
  public.platform_features,
  public.project_versions,
  public.project_members,
  public.project_events,
  public.execution_balances,
  public.execution_status_factors,
  public.quality_incidents,
  public.training_events,
  public.training_financial_rates,
  public.training_participants,
  public.project_rewards,
  public.transport_entitlements,
  public.project_advances,
  public.financial_ledger,
  public.financial_documents,
  public.financial_document_lines,
  public.financial_settlements
to authenticated;

grant usage, select on sequence public.project_events_id_seq
to authenticated, service_role;

grant select on public.v_execution_project_summary_v11 to authenticated, service_role;
grant select on public.v_project_financial_position_v11 to authenticated, service_role;

-- RPC execution
do $$
declare
  r record;
begin
  for r in
    select p.oid::regprocedure as sig
    from pg_proc p
    join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public'
      and p.proname in (
        'log_project_event_v11',
        'approve_execution_balance_v11',
        'approve_quality_incident_v11',
        'recalculate_training_event_v11',
        'post_training_event_entitlements_v11',
        'issue_training_reward_documents_v11',
        'create_project_reward_v11',
        'approve_project_reward_v11',
        'create_transport_entitlement_v11',
        'approve_transport_entitlement_v11',
        'create_project_advance_v11',
        'approve_project_advance_v11',
        'mark_project_advance_paid_v11',
        'recalculate_fieldwork_entitlements_v11',
        'approve_calculated_fieldwork_v11',
        'snapshot_project_settlements_v11'
      )
  loop
    execute format('revoke execute on function %s from public, anon', r.sig);
    execute format('grant execute on function %s to authenticated, service_role', r.sig);
  end loop;
end
$$;

-- Trigger function is internal only
revoke execute on function public.v11_training_participant_snapshot()
from public, anon, authenticated;

commit;

-- =====================================================================
-- 12. VERIFICATION — ONE JSON RESULT
-- =====================================================================

with expected_tables(name) as (
  values
    ('platform_features'),
    ('project_versions'),
    ('project_members'),
    ('project_events'),
    ('execution_balances'),
    ('execution_status_factors'),
    ('quality_incidents'),
    ('training_events'),
    ('training_financial_rates'),
    ('training_participants'),
    ('project_rewards'),
    ('transport_entitlements'),
    ('project_advances'),
    ('financial_ledger'),
    ('financial_documents'),
    ('financial_document_lines'),
    ('financial_settlements')
),
table_check as (
  select
    e.name,
    to_regclass('public.'||e.name) is not null as exists
  from expected_tables e
),
function_check as (
  select
    p.proname as name,
    has_function_privilege('anon',p.oid,'EXECUTE') as anon_execute,
    has_function_privilege('authenticated',p.oid,'EXECUTE') as authenticated_execute
  from pg_proc p
  join pg_namespace n on n.oid=p.pronamespace
  where n.nspname='public'
    and p.proname like '%_v11'
),
rls_check as (
  select c.relname as name,c.relrowsecurity as rls_enabled
  from pg_class c
  join pg_namespace n on n.oid=c.relnamespace
  where n.nspname='public'
    and c.relname in (select name from expected_tables)
)
select jsonb_pretty(
  jsonb_build_object(
    'release','V11.0-RC1',
    'baseline_preserved','V10.2.10',
    'feature_enabled',
      (select enabled from public.platform_features where feature_key='project_workspace_v11'),
    'tables',
      (select jsonb_agg(jsonb_build_object('name',name,'exists',exists) order by name) from table_check),
    'rls',
      (select jsonb_agg(jsonb_build_object('name',name,'enabled',rls_enabled) order by name) from rls_check),
    'functions',
      (select jsonb_agg(jsonb_build_object(
        'name',name,
        'anon_execute',anon_execute,
        'authenticated_execute',authenticated_execute
      ) order by name) from function_check),
    'views',
      jsonb_build_object(
        'execution_summary',to_regclass('public.v_execution_project_summary_v11') is not null,
        'financial_position',to_regclass('public.v_project_financial_position_v11') is not null
      )
  )
) as v11_rc1_verification;
